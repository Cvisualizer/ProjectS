int a,b,c;

int add(int x,int y){
return x+y;
}

int main(){
a=13;
b=36;
c=add(a,b);
}